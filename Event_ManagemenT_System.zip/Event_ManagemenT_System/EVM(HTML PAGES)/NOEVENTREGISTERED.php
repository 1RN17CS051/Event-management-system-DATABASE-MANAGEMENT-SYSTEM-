<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>NO REGISTERED EVENTS</title>
        <?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
        <?php require 'utils/scripts.php'; ?><!--js links. file found in utils folder-->
        <style>
        .example_c {
color: #494949 !important;
text-transform: uppercase;
text-decoration: none;
background: #ffffff;
padding: 20px;
border: 4px solid #494949 !important;
display: inline-block;
transition: all 0.4s ease 0s;
}
.example_c:hover {
color: #ffffff !important;
background: #f6b93b;
border-color: #f6b93b !important;
transition: all 0.4s ease 0s;
}</style>
    </head>
    <body>
        
        <?php require 'utils/header.php'; ?><!--header content. file found in utils folder-->
   <h3 align="center" style="color:red">No Events Registerd....!!!</h3>
<h5 align="center">Click the Button Below to Explore...</h5>
                  <h5 align="center">_____________________________</h5>
<br>
<br>
<br>              
    <h5><div class="button_c" align="center"><a class="example_c" href="EXPLOREEVENTS.php" >Explore Events..</a></div></h5>
                  <h2 align="center">_____________________________</h2>
 
                 <h2 align="center"><strong>E.V.E.N.T.R.O.N</strong></h2>
                    <h2 align="center">_____________________________</h2>
               
            <div class="container">
            <div class="col-md-12">
            <hr>
            </div>
            </div>
			
            <div class="row"><!--event content-->
                <section>
                    <div class="container">
                        <h></h>
                    </div><!--container div-->
                </section>
            </div><!--row div--> 	
        
    <?php require 'utils/footer.php'; ?><!--footer content. file found in 
utils folder-->
                        
    </body>
</html>