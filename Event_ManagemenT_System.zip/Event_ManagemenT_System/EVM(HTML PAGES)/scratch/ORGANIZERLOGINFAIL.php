<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>LOGIN FAILURE</title>
        <?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
        <?php require 'utils/scripts.php'; ?><!--js links. file found in utils folder-->
    </head>
    <body>
        <?php require 'utils/header2.php'; ?><!--header content. file found in utils folder-->
        <div class="content"><!--body content holder-->
            <div class="container">
                <div class="col-md-12"><!--body content title holder with 12 grid columns-->
                    <h1 align="center">Failed To Log In..</h1>
                    <p align="center">Try  to login again with right credendials/User does not exist !</p>
                    <h1><div class="button_c" align="center"><a class="example_c" href="ORGANIZER_LOGIN.php" >LOGIN</a></div></h1><!--body content title-->
                    <h2 align="center">______________________________</h2>
                 <h2 align="center"><strong>E.V.E.N.T.R.O.N</strong></h2>
                    <h2 align="center">_____________________________</h2>
                    
                    
                </div>
            </div>
			
            <div class="container">
            <div class="col-md-12">
            <hr>
            </div>
            </div>
			
            <div class="row"><!--event content-->
                <section>
                    <div class="container">
                        <h></h>
                    </div><!--container div-->
                </section>
            </div><!--row div-->
			
          
                    </div><!--container div-->	
        
        <?php require 'utils/footer.php'; ?><!--footer content. file found in utils folder-->
    </body>
</html>
