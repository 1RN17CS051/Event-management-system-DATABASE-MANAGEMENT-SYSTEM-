<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong><span class = "small footerSubtext"> </span></strong>
                        <span class = "small footerSubtext">Developed by</span>
                    </p>
 
                     <p class = "footerSubtext2">
                         <li> Mohammed suhail</li>
                         <li>Mohammed zabiulla</li>
                     </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    <strong>R N S INSTITUTE OF TECHNOLOGY</strong><br>
                    Channasandra, Uttarhalli Road, Bangalore-560098<br>
                </div>
            </section>
        
        </div>
    </div>
</footer>