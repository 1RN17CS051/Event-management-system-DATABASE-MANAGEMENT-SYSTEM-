<?php
	
	$conn = mysqli_connect('localhost','id11721754_root','12345678','id11721754_dbmsproject	');
	if($conn==false)
	{
		echo "connection is not done";
	}
	
?>