<?php
	
	$conn = mysqli_connect('localhost','root','','dbms project');
	if($conn==false)
	{
		echo "connection is not done";
	}
	
?>